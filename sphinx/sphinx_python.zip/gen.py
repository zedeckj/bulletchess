from bulletchess import *


for pt in PIECE_TYPES:
    print(f"{str(pt).upper()}: PieceType")
    print('"""')
    print(f"The :class:`PieceType` for {str(pt).lower()}s")
    print('"""\n')
