#ifndef EVALHEADER 
#define EVALHEADER
#include "move.h"

int32_t shannon(full_board_t * board);

#endif
